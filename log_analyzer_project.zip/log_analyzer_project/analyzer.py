import re
import pandas as pd
import matplotlib.pyplot as plt
import os

# Load the log file
log_file = "logs/auth.log"
if not os.path.exists(log_file):
    print("Log file not found!")
    exit()

ip_list = []

# Extract IPs from failed password attempts
with open(log_file, "r") as f:
    for line in f:
        match = re.search(r"Failed password.*from (\d+\.\d+\.\d+\.\d+)", line)
        if match:
            ip_list.append(match.group(1))

# Create DataFrame
df = pd.DataFrame(ip_list, columns=["IP"])

# Count IPs
ip_counts = df["IP"].value_counts()
print("Top 10 Brute-force IPs:\n")
print(ip_counts.head(10))

# Save CSV report
report_path = "report_output/intrusion_report.csv"
ip_counts.to_csv(report_path)
print(f"\nCSV report saved to {report_path}")

# Plot bar chart
# Plot bar chart only if data exists
if not ip_counts.empty:
    import matplotlib.pyplot as plt
    plt.figure(figsize=(10, 6))
    ip_counts.head(10).plot(kind="bar", color="tomato")
    plt.title("Top 10 Brute-Force IPs")
    plt.xlabel("IP Address")
    plt.ylabel("Number of Failed Attempts")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig("report_output/brute_force_ips.png")
    plt.show()
else:
    print("No brute-force attempts found in the log file.")

