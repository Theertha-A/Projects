import csv
from datetime import datetime

file = input("Enter filename: ")
hash_value = input("Enter SHA-256 hash: ")

with open("log.csv", "a", newline="") as log:
    writer = csv.writer(log)
    writer.writerow([file, datetime.now(), hash_value])

print("📄 Metadata logged successfully.")
