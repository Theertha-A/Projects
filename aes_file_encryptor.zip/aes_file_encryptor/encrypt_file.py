from cryptography.fernet import Fernet
import hashlib
import os

def hash_file(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

# Load key
with open("aes.key", "rb") as f:
    key = f.read()

cipher = Fernet(key)

file_to_encrypt = input("Enter filename to encrypt: ")

with open(file_to_encrypt, "rb") as f:
    data = f.read()

encrypted_data = cipher.encrypt(data)

# Save encrypted file
with open(file_to_encrypt + ".enc", "wb") as f:
    f.write(encrypted_data)

# Save hash
original_hash = hash_file(file_to_encrypt)
print("✅ File encrypted successfully.")
print("🔒 SHA-256 Hash of original file:", original_hash)
