from cryptography.fernet import Fernet

# Load key
with open("aes.key", "rb") as f:
    key = f.read()

cipher = Fernet(key)

encrypted_file = input("Enter filename to decrypt (with .enc): ")

with open(encrypted_file, "rb") as f:
    encrypted_data = f.read()

decrypted_data = cipher.decrypt(encrypted_data)

output_file = encrypted_file.replace(".enc", "_decrypted.txt")

with open(output_file, "wb") as f:
    f.write(decrypted_data)

print(f"✅ File decrypted and saved as {output_file}")
